//
//  message.swift
//  practiceMessenger
//
//  Created by Amanda Burger on 5/15/20.
//  Copyright © 2020 Amanda Burger. All rights reserved.
//

class message{
    var sender : String = ""
    var messageBody : String = ""
    
}
