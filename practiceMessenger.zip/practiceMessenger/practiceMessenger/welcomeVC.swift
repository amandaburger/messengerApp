//
//  ViewController.swift
//  practiceMessenger
//
//  Created by Amanda Burger on 5/12/20.
//  Copyright © 2020 Amanda Burger. All rights reserved.
//

import UIKit

class welcomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

